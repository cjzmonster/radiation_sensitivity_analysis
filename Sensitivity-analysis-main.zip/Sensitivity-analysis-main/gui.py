import torch
import torch.nn as nn
import numpy as np
import pandas as pd

import tkinter as tk
from tkinter import Label, Scale, HORIZONTAL, ttk, messagebox
import copy

class RegressionModel(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(RegressionModel, self).__init__()
        self.fc1 = nn.Linear(input_dim, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, output_dim)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)
        return x


input_dim = 9
output_dim = 5
model = RegressionModel(input_dim, output_dim)
model.load_state_dict(torch.load('./model/qr.pth'))

# 创建主窗口
root = tk.Tk()
root.title("模型预测")

# 设置窗口大小
root.geometry("400x300")

# 用于保存滑块和下拉框的值
param_values = {}
# 定义连续参数的滑块
def create_slider(label_text, param_name, from_, to_, row):
    label = tk.Label(root, text=label_text)
    label.grid(row=row, column=0, padx=10, pady=10)

    slider = tk.Scale(root, from_=from_, to=to_, orient=tk.HORIZONTAL, resolution=0.1)
    slider.grid(row=row, column=1, padx=10, pady=10)
    param_values[param_name] = slider

# 定义离散参数的下拉框
def create_dropdown(label_text, param_name, options, row):
    label = tk.Label(root, text=label_text)
    label.grid(row=row, column=0, padx=10, pady=10)

    combobox = ttk.Combobox(root, values=options, state="readonly")
    combobox.grid(row=row, column=1, padx=10, pady=10)
    combobox.current(0)  # 默认选择第一个选项
    param_values[param_name] = combobox

# 生成一些示例滑块和下拉框
create_slider("锥体高度", "param1", 1, 5, 0)
create_slider("球头半径", "param2", 0.005, 0.1, 1)
create_slider("底部直径", "param3", 0.5, 2.5, 2)
create_slider("角度", "param4", 0, 90, 3)
create_dropdown("波段", "param5", ["C", "S", "X"], 4)
create_dropdown("极化方式", "param6", ["hh", "vv"], 5)

one_hot_feature_channel = {'C':[1, 0, 0], 'S':[0, 1, 0], 'X':[0, 0, 1]}
one_hot_feature_polar = {'hh':[1, 0], 'vv':[0, 1]}

# 定义用于one-hot编码的函数
def one_hot_encode(option, options):
    encoding = [0] * len(options)
    encoding[options.index(option)] = 1
    return encoding

# 进行预测的函数
def make_prediction():
    # 提取滑块值
    param1 = param_values["param1"].get()
    param2 = param_values["param2"].get()
    param3 = param_values["param3"].get()
    param4 = param_values["param4"].get()
    param5 = param_values["param5"].get()
    param6 = param_values["param6"].get()

    # 构建输入特征向量
    feature_stable = np.array([param1, param2, param3, param4])
    feature_channel = one_hot_feature_channel[param5]
    feature_polar = one_hot_feature_polar[param6]
    feature = np.hstack((feature_stable, np.array(feature_channel), np.array(feature_polar)))
    x_tensor = torch.tensor(feature).float()

    # 使用模型进行预测
    with torch.no_grad():
        y = model(x_tensor).cpu().numpy()

    # 显示预测结果
    messagebox.showinfo("预测结果", f"预测结果: {y[0]}")

if __name__ == "__main__":

    predict_button = tk.Button(root, text="预测", command=make_prediction)
    predict_button.grid(row=8, column=0, columnspan=2, padx=10, pady=10)

    # 启动主循环
    root.mainloop()